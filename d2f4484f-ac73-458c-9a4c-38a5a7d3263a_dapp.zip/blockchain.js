const fs = require('fs');
const crypto = require('crypto');

class Block {
    constructor(index, previousHash, timestamp, data, nonce) {
        this.index = index;
        this.previousHash = previousHash;
        this.timestamp = timestamp;
        this.data = data;
        this.nonce = nonce;
        this.hash = this.calculateHash();
    }

    calculateHash() {
        return crypto
            .createHash('sha256')
            .update(
                this.index +
                this.previousHash +
                this.timestamp +
                JSON.stringify(this.data) +
                this.nonce
            )
            .digest('hex');
    }
}

class Blockchain {
    constructor() {
        this.chain = this.loadFromFile('blockchain.json'); // Load blockchain data from a JSON file
        if (!this.chain || this.chain.length === 0) {
            this.chain = [this.createGenesisBlock()];
        }
    }

    createGenesisBlock() {
        return new Block(0, '0', new Date().toISOString(), 'Genesis Block', 0);
    }

    getLatestBlock() {
        return this.chain[this.chain.length - 1];
    }

    mineBlock(data) {
        const previousBlock = this.getLatestBlock();
        const newIndex = previousBlock.index + 1;
        let nonce = 0;
        let newHash = '';

        while (
            newHash.substring(0, 4) !== '0000' // Proof-of-work requirement (adjust as needed)
        ) {
            nonce++;
            newHash = new Block(
                newIndex,
                previousBlock.hash,
                new Date().toISOString(),
                data,
                nonce
            ).calculateHash();
        }

        const newBlock = new Block(
            newIndex,
            previousBlock.hash,
            new Date().toISOString(),
            data,
            nonce
        );
        this.chain.push(newBlock);
    }

    isChainValid() {
        for (let i = 1; i < this.chain.length; i++) {
            const currentBlock = this.chain[i];
            const previousBlock = this.chain[i - 1];

            if (currentBlock.hash !== currentBlock.calculateHash()) {
                return false;
            }

            if (currentBlock.previousHash !== previousBlock.hash) {
                return false;
            }
        }

        return true;
    }

    toJSON() {
        return JSON.stringify(this.chain, null, 2); // 2 for pretty formatting
    }

    loadFromFile(filename) {
        try {
            const data = fs.readFileSync(filename, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('Error loading blockchain from file:', error.message);
            return null;
        }
    }
    saveToFile(filename) {
        const data = this.toJSON();
        fs.writeFileSync(filename, data);
    }
}

module.exports = Blockchain;
