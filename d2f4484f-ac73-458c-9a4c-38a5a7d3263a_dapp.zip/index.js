const express = require('express');
const bodyParser = require('body-parser');
const Blockchain = require('./blockchain');

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Serve static files from the 'public' folder
app.use(express.static(__dirname + '/public'));

app.set('view engine', 'ejs');

// Function to render the index page with the latest blockchain data
function renderIndexPage(req, res) {
    const myBlockchain = new Blockchain(); // Load blockchain data from the JSON file
    res.render('index', { blockchainData: myBlockchain.chain });
}

app.get('/', (req, res) => {
    renderIndexPage(req, res);
});

app.get('/add-block', (req, res) => {
    res.render('add-block');
});

app.post('/add-block', (req, res) => {
    const data = req.body.data;
    const myBlockchain = new Blockchain(); // Load blockchain data from the JSON file
    myBlockchain.mineBlock(data);

    // Save blockchain data to a JSON file
    myBlockchain.saveToFile('blockchain.json');

    // Redirect to the index page after adding a block
    renderIndexPage(req, res);
});

// ...

app.get('/mine', (req, res) => {
    const searchString = req.query.searchString ? req.query.searchString.toLowerCase() : null;
    let filteredBlocks = [];

    if (searchString !== null && searchString.trim() !== '') {
        const myBlockchain = new Blockchain();
        filteredBlocks = myBlockchain.chain.filter(block => {
            return block.data.toLowerCase().includes(searchString);
        });
    }

    res.render('mine', { filteredBlocks, searchString });
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
